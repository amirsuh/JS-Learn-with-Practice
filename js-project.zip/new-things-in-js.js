let cArr = [1,2,3].values()
//debugger
const resultc = cArr.map(v=>v*2).toArray()